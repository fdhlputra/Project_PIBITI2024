<x-layout subPage='Orders' title="Order Tracking" subtitle="Track and manage your customer orders">
    <style>
        .order-content {
            height: 100%;
            overflow-x: hidden;
        }

        .order-body {
            display: flex;
            align-items: center;
            justify-content: space-between;
            height: 20%;
            padding: 10px;
            position: sticky;
            top: 0;
            background-color: white;
            z-index: 1;
        }

        .form-control {
            width: 300px;
            padding: 0.5rem 1rem;
            font-size: 1rem;
            border-radius: 20px;
        }

        #searchInput:focus {
            outline: none !important;
            box-shadow: none !important;
        }
    </style>
    <div class="order-content">
        <div class="order-body bg-light stroke">
            <div class="w-100">
                <div class="w-100 justify-content-between align-items-center ps-3 py-2 mb-4">
                    <div class="d-flex mb-2 justify-content-between">
                        @if (request()->get('search') && $orders->isEmpty())
                            <h4>No results found for "{{ request()->get('search') }}"</h4>
                        @else
                            <h4>
                                {{ request()->get('search') ? 'Search for "' . request()->get('search') . '"' : 'All Orders' }},
                                <span class="opacity-75">{{ $orders->count() }}</span>
                            </h4>
                        @endif
                        <div class="d-flex gap-2">
                            <form class="d-flex gap-2" method="get">
                                <input type="text" class="form-control" placeholder="Search order..." name="search"
                                    value="{{ request()->search }}">
                            </form>
                            @if (Auth::user()->authority != 'user')
                                <a href="{{ route('orders.create') }}"
                                    class="btn btn-dark rounded-pill d-flex justify-content-center align-items-center px-3 py-2 ">
                                    <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24"
                                        viewBox="0 0 24 24" class="me-1">
                                        <path fill="currentColor"
                                            d="M11 13H6q-.425 0-.712-.288T5 12t.288-.712T6 11h5V6q0-.425.288-.712T12 5t.713.288T13 6v5h5q.425 0 .713.288T19 12t-.288.713T18 13h-5v5q0 .425-.288.713T12 19t-.712-.288T11 18z" />
                                    </svg>
                                    <span>Create New Orders</span>
                                </a>
                            @endif
                        </div>
                    </div>

                    <div class="table-responsive pt-3">
                        <table class="table m-0">
                            <thead>
                                <tr>
                                    <th>Customer</th>
                                    <th>Payment</th>
                                    <th>Total</th>
                                    <th>User</th>
                                    <th></th>
                                </tr>
                            </thead>

                            <tbody>
                                @forelse ($orders as $order)
                                    <tr>
                                        <td>{{ $order->customer }}</td>
                                        <td>{{ number_format($order->payment) }}</td>
                                        <td>{{ number_format($order->total) }}</td>
                                        <td>{{ $order->user->name }}</td>
                                        <td style="width: 150px">
                                            <a href="{{ route('orders.show', ['order' => $order->id]) }}"
                                                class="btn border border-secondary rounded-pill d-flex justify-content-center align-items-center px-4 py-2">
                                                View Detail
                                            </a>
                                        </td>
                                    </tr>
                                @empty
                                    <tr>
                                        <td colspan="5">No orders found.</td>
                                    </tr>
                                @endforelse
                            </tbody>
                        </table>
                    </div>


                </div>
            </div>
        </div>
    </div>

    <div class="container">
        @if (session('success'))
            <div class="alert alert-success" role="alert">
                {{ session('success') }}
            </div>
        @endif

    </div>
</x-layout>
