import './bootstrap';

/* document.addEventListener('DOMContentLoaded', function() {
    const searchInput = document.getElementById('searchInput');
    searchInput.focus();

    const query = searchInput.value;
    searchInput.setSelectionRange(query.length, query.length);

    searchInput.addEventListener('input', function() {
        const newQuery = this.value;

        if (newQuery.length > 0) {
            const url = `${window.location.pathname}?search=${encodeURIComponent(newQuery)}`;
            window.location.href = url;
        } else {
            window.location.href = window.location.pathname;
        }
    });
});
 */
