<?php if (isset($component)) { $__componentOriginal23a33f287873b564aaf305a1526eada4 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal23a33f287873b564aaf305a1526eada4 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.layout','data' => ['subPage' => 'Product','title' => 'Product Listing','subtitle' => 'Add, edit, and manage your product listings.']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['subPage' => 'Product','title' => 'Product Listing','subtitle' => 'Add, edit, and manage your product listings.']); ?>
    <style>
        .form-control {
            width: 300px;
            padding: 0.5rem 1rem;
            font-size: 1rem;
            border-radius: 20px;
        }

        #searchInput:focus {
            outline: none !important;
            box-shadow: none !important;
        }

        .card {
            border-radius: 15px;
            background-color: #f8f9fa;
        }

        .product-card:hover .sold-overlay .sold-text {
            display: none;
        }

        .product-card:hover .overlay .overlay-text {
            display: block;
        }

        .product-card .overlay .overlay-text {
            display: none;
        }

        /* add edit content */
        .product-content {
            height: 100%;
            overflow-x: hidden;
        }

        .product-body {
            display: flex;
            align-items: center;
            justify-content: space-between;
            height: 20%;
            padding: 10px;
            position: sticky;
            top: 0;
            background-color: white;
            z-index: 1;
        }

        .product-body .row .col-12,
        .product-body .row .col-md-4,
        .product-body .row .col-lg-4 {
            margin-bottom: 0 !important;
            padding: 0;
        }
    </style>
    <div class="product-content">
        <div class="product-body bg-light stroke">
            <div class="w-100">
                <div class="w-100 justify-content-between align-items-center ps-3 pt-2">
                    <div class="d-flex mb-2 justify-content-between">
                        <?php if(request()->get('search') && $products->isEmpty()): ?>
                            <h4>No results found for "<?php echo e(request()->get('search')); ?>"</h4>
                        <?php else: ?>
                            <h4>
                                <?php echo e(request()->get('search') ? 'Search for "' . request()->get('search') . '"' : 'All Products'); ?>,
                                <span class="opacity-75"><?php echo e($products->count()); ?></span>
                            </h4>
                        <?php endif; ?>
                        <div class="d-flex gap-2">
                            <form class="d-flex gap-2" method="get">
                                <input type="text" class="form-control w-auto" placeholder="Search products"
                                    name="search" value="<?php echo e(request()->search); ?>">
                            </form>
                            <?php if(Auth::user()->authority != 'user'): ?>
                                <a href="<?php echo e(route('products.create')); ?>"
                                    class="btn btn-dark rounded-pill d-flex justify-content-center align-items-center px-3 py-2">
                                    <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24"
                                        viewBox="0 0 24 24" class="me-1">
                                        <path fill="currentColor"
                                            d="M11 13H6q-.425 0-.712-.288T5 12t.288-.712T6 11h5V6q0-.425.288-.712T12 5t.713.288T13 6v5h5q.425 0 .713.288T19 12t-.288.713T18 13h-5v5q0 .425-.288.713T12 19t-.712-.288T11 18z" />
                                    </svg>
                                    <span>Add Products</span>
                                </a>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    
    <div class="product-content">
        <div class="product-body bg-transparent stroke">
            <div class="row row-cols-1 row-cols-lg-3">
                <?php $__empty_1 = true; $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <div class="col-md-4 col-lg-4">
                        <a href="<?php echo e(route('products.edit', ['product' => $product->id])); ?>"
                            class="text-decoration-none">
                            <div class="card product-card <?php echo e(!$product->active ? 'inactive-card' : ''); ?>">
                                <img src="<?php echo e(Storage::url($product->image)); ?>"
                                    class="card-img-top img-thumbnail bg-light rounded-lg" alt="<?php echo e($product->name); ?>"
                                    style="width: 100%; height:320px; object-fit:cover; border-radius:10px">
                                <?php if($product->stock <= 0): ?>
                                    <div class="sold-overlay">
                                        <div class="sold-text">Out of Stock</div>
                                    </div>
                                <?php endif; ?>
                                <div class="overlay">
                                    <div class="overlay-text">View Product</div>
                                </div>
                                <div class="card-body">
                                    <h5 class="card-title fs-3"><?php echo e($product->name); ?></h5>
                                    <p class="card-text fw-medium">Rp.<?php echo e($product->price); ?></p>
                                    <p>
                                        <?php if($product->active): ?>
                                            <span class="badge rounded-pill text-bg-primary">Ready</span>
                                            <span
                                                class="badge rounded-pill text-bg-success"><?php echo e($product->category->name); ?></span>
                                        <?php else: ?>
                                            <span class="badge rounded-pill text-bg-danger">Sold Out</span>
                                            <span
                                                class="badge rounded-pill text-bg-success"><?php echo e($product->category->name); ?></span>
                                        <?php endif; ?>
                                    </p>
                                </div>
                            </div>
                        </a>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <div class="product-content w-100">
                        <div class="alert alert-warning text-center" role="alert">
                            Product is empty.
                        </div>
                    </div>
                <?php endif; ?>
            </div>
        </div>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal23a33f287873b564aaf305a1526eada4)): ?>
<?php $attributes = $__attributesOriginal23a33f287873b564aaf305a1526eada4; ?>
<?php unset($__attributesOriginal23a33f287873b564aaf305a1526eada4); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal23a33f287873b564aaf305a1526eada4)): ?>
<?php $component = $__componentOriginal23a33f287873b564aaf305a1526eada4; ?>
<?php unset($__componentOriginal23a33f287873b564aaf305a1526eada4); ?>
<?php endif; ?>
<?php /**PATH D:\PIBITI 2024\firstApp\resources\views/product/index.blade.php ENDPATH**/ ?>