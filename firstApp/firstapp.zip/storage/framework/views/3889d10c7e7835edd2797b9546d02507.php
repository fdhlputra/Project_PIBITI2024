<?php if (isset($component)) { $__componentOriginal23a33f287873b564aaf305a1526eada4 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal23a33f287873b564aaf305a1526eada4 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.layout','data' => ['subPage' => 'Orders','title' => 'Order Summary','subtitle' => 'Overview of the order information','action' => 'Order Details']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['subPage' => 'Orders','title' => 'Order Summary','subtitle' => 'Overview of the order information','action' => 'Order Details']); ?>
    <style>
        .order-content {
            height: 100%;
            overflow-x: hidden;
        }

        .order-body {
            display: flex;
            align-items: center;
            justify-content: space-between;
            padding: 10px;
            background-color: white;
            border: 1px solid #ddd;
            margin-bottom: 10px;
        }

        .order-body img {
            max-width: 150px;
            max-height: 150px;
        }
    </style>

    <div class="order-content">
        <!-- Header Section -->
        <div class="order-body bg-light stroke p-3">
            <h4>Total Items,     <?php echo e($order->details->count()); ?></h4>
            <a href="<?php echo e(route('orders.index')); ?>"
                class="btn border border-secondary rounded-pill d-flex justify-content-center align-items-center px-3 py-2"
                style="width: 100px">Back</a>
        </div>

        <!-- Content Section -->
        <div class="d-flex flex-wrap gap-2 w-100">
            <!-- Items Details Column -->
            <div class="flex-grow-1">
                <?php $__currentLoopData = $order->details; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $detail): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="order-body bg-light stroke p-3">
                        <div class="d-flex flex-column flex-md-row">
                            <div class="me-md-3">
                                <img src="<?php echo e(asset('storage/' . $detail->product->image)); ?>"
                                    alt="<?php echo e($detail->product->name); ?>" class="img-thumbnail">
                            </div>
                            <div>
                                <h5 class="fw-medium mb-3"><?php echo e($detail->product->name); ?></h5>
                                <div class="fs-6 mb-2">Price: Rp<?php echo e(number_format($detail->price)); ?></div>
                                <div class="fs-6 mb-2">Count: <?php echo e($detail->quantity); ?></div>
                                <div class="fs-6 mb-2">Subtotal:
                                    Rp<?php echo e(number_format($detail->quantity * $detail->price)); ?>

                                </div>
                            </div>
                        </div>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>

            <!-- Summary Column -->
            <div class="order-body bg-light p-3 stroke order-summary d-flex flex-column" style="width: 400px">
                <div class="w-100">
                    <h5 class="fw-medium  fs-4 mb-3">Summary</h5>
                    <?php $__currentLoopData = $order->details; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $detail): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="d-flex justify-content-between">
                            <div class="fs-6 mb-2">
                                Subtotal <?php echo e($index + 1); ?> :
                            </div>
                            <div>
                                Rp. <?php echo e(number_format($detail->quantity * $detail->price)); ?>

                            </div>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <hr>
                    <div class="d-flex justify-content-between mb-2">
                        <div>Total :</div>
                        <div class="fw-semibold">Rp<?php echo e(number_format($order->total)); ?></div>
                    </div>
                    <div class="d-flex justify-content-between mb-2">
                        <div>Payment :</div>
                        <div>Rp<?php echo e(number_format($order->payment)); ?></div>
                    </div>
                    <hr>
                    <div class="d-flex justify-content-between fw-bold">
                        <div>Change :</div>
                        <div>Rp<?php echo e(number_format($order->payment - $order->total)); ?></div>
                    </div>
                </div>
            </div>
        </div>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal23a33f287873b564aaf305a1526eada4)): ?>
<?php $attributes = $__attributesOriginal23a33f287873b564aaf305a1526eada4; ?>
<?php unset($__attributesOriginal23a33f287873b564aaf305a1526eada4); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal23a33f287873b564aaf305a1526eada4)): ?>
<?php $component = $__componentOriginal23a33f287873b564aaf305a1526eada4; ?>
<?php unset($__componentOriginal23a33f287873b564aaf305a1526eada4); ?>
<?php endif; ?>
<?php /**PATH D:\PIBITI 2024\firstApp\resources\views/order/show.blade.php ENDPATH**/ ?>