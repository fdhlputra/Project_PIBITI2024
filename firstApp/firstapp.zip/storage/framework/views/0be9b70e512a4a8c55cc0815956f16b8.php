<?php if (isset($component)) { $__componentOriginal23a33f287873b564aaf305a1526eada4 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal23a33f287873b564aaf305a1526eada4 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.layout','data' => ['subPage' => 'User','action' => 'Edit User','title' => 'User Management','subtitle' => 'Edit user account and assign permissions.']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['subPage' => 'User','action' => 'Edit User','title' => 'User Management','subtitle' => 'Edit user account and assign permissions.']); ?>
    <div class="container mt-3 mb-4 stroke">
        <div class="row justify-content-center">
            <div class="col-md-8 col-lg-6">
                <div class="card shadow-sm">
                    <div class="card-body text-center">
                        <h5 class="card-title mb-4 fs-4 fw-medium">Edit User</h5>
                        <form action="<?php echo e(route('users.update', $user->id)); ?>" method="post"
                            enctype="multipart/form-data">
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('PUT'); ?>
                            <div class="mb-3">
                                <label class="form-label">Profile Photo</label>
                                <div class="mb-2">
                                    <img src="<?php echo e($user->photo_file ? Storage::url($user->photo_file) : (filter_var($user->photo_url, FILTER_VALIDATE_URL) ? $user->photo_url : asset('path/to/default-image.jpg'))); ?>"
                                        alt="User Photo" class="rounded-circle mb-3"
                                        style="width: 100px; height: 100px; object-fit: cover;">
                                </div>
                                <a href="<?php echo e(route('users.editPhoto', $user->id)); ?>" class="btn btn-dark mb-3">Edit
                                    Photo</a>
                            </div>

                            <div class="mb-3 text-start">
                                <label for="name" class="form-label">Name</label>
                                <input type="text" class="form-control <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                    id="name" name="name" placeholder="Your name"
                                    value="<?php echo e(old('name', $user->name)); ?>">
                                <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <div class="invalid-feedback"><?php echo e($message); ?></div>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                            <div class="mb-3 text-start">
                                <label for="email" class="form-label">Email</label>
                                <input type="email" class="form-control <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                    id="email" name="email" placeholder="Input your email"
                                    value="<?php echo e(old('email', $user->email)); ?>">
                                <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <div class="invalid-feedback"><?php echo e($message); ?></div>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                            
                            <?php if(Auth::user()->authority == 'superadmin'): ?>
                                <div class="mb-4 text-start">
                                    <h5>Edit Authority</h5>

                                    <div class="form-check form-switch">
                                        <input class="form-check-input" type="radio" id="superadmin" name="authority"
                                            value="superadmin" <?php echo e($user->authority == 'superadmin' ? 'checked' : ''); ?>

                                            <?php echo e($user->authority == 'superadmin' ? 'disabled' : ''); ?>

                                            onclick="toggleAuthority('superadmin')">
                                        <label class="form-check-label fw-semibold" for="superadmin">Super Admin</label>
                                        <p>manage all aspects of the system.</p>
                                    </div>

                                    <div class="form-check form-switch">
                                        <input class="form-check-input" type="radio" id="admin" name="authority"
                                            value="admin" <?php echo e($user->authority == 'admin' ? 'checked' : ''); ?>

                                            <?php echo e($user->authority == 'superadmin' ? 'disabled' : ''); ?>

                                            onclick="toggleAuthority('admin')">
                                        <label class="form-check-label fw-semibold" for="admin">Admin</label>
                                        <p>manage content and change team setting</p>
                                    </div>

                                    <div class="form-check form-switch">
                                        <input class="form-check-input" type="radio" id="user" name="authority"
                                            <?php echo e($user->authority == 'superadmin' ? 'disabled' : ''); ?> value="user"
                                            <?php echo e($user->authority == 'user' ? 'checked' : ''); ?>

                                            onclick="toggleAuthority('user')">
                                        <label class="form-check-label fw-semibold" for="user">User</label>
                                        <p>only view content and access information.</p>
                                    </div>
                                </div>
                            <?php endif; ?>


                            
                            <div class="d-flex justify-content-end">
                                <button type="submit" class="btn btn-dark">Update User</button>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <script>
        function toggleAuthority(selectedAuthority) {
            if (selectedAuthority === 'superadmin') {
                document.getElementById('admin').checked = false;
                document.getElementById('user').checked = false;
            } else if (selectedAuthority === 'admin') {
                document.getElementById('superadmin').checked = false;
                document.getElementById('user').checked = false;
            } else if (selectedAuthority === 'user') {
                document.getElementById('superadmin').checked = false;
                document.getElementById('admin').checked = false;
            }
        }
    </script>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal23a33f287873b564aaf305a1526eada4)): ?>
<?php $attributes = $__attributesOriginal23a33f287873b564aaf305a1526eada4; ?>
<?php unset($__attributesOriginal23a33f287873b564aaf305a1526eada4); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal23a33f287873b564aaf305a1526eada4)): ?>
<?php $component = $__componentOriginal23a33f287873b564aaf305a1526eada4; ?>
<?php unset($__componentOriginal23a33f287873b564aaf305a1526eada4); ?>
<?php endif; ?>
<?php /**PATH D:\PIBITI 2024\firstApp\resources\views/users/edit.blade.php ENDPATH**/ ?>