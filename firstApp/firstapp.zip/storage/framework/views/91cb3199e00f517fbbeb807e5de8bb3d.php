<?php if (isset($component)) { $__componentOriginal23a33f287873b564aaf305a1526eada4 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal23a33f287873b564aaf305a1526eada4 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.layout','data' => ['subPage' => 'Category','title' => 'Categories Organization','subtitle' => 'Organize your items into various categories.']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['subPage' => 'Category','title' => 'Categories Organization','subtitle' => 'Organize your items into various categories.']); ?>
    <style>
        .category-content {
            height: 100%;
            overflow-x: hidden;
        }

        .category-body {
            display: flex;
            align-items: center;
            justify-content: space-between;
            height: 20%;
            padding: 10px;
            position: sticky;
            top: 0;
            background-color: white;
            z-index: 1;
        }

        .form-control {
            width: 300px;
            padding: 0.5rem 1rem;
            font-size: 1rem;
            border-radius: 20px;
        }

        #searchInput:focus {
            outline: none !important;
            box-shadow: none !important;
        }
    </style>
    <div class="container">
        <?php if(session('success')): ?>
            <div class="alert alert-success" role="alert">
                <?php echo e(session('success')); ?>

            </div>
        <?php endif; ?>
    </div>
    <div class="category-content">
        <div class="category-body bg-light stroke">
            <div class="w-100">
                <div class="w-100 justify-content-between align-items-center ps-3 py-2 mb-4">
                    <div class="d-flex mb-2 justify-content-between">
                        <?php if(request()->get('search') && $categories->isEmpty()): ?>
                            <h4>No results found for "<?php echo e(request()->get('search')); ?>"</h4>
                        <?php else: ?>
                            <h4>
                                <?php echo e(request()->get('search') ? 'Search for "' . request()->get('search') . '"' : 'All Categories'); ?>,
                                <span class="opacity-75"><?php echo e($categories->count()); ?></span>
                            </h4>
                        <?php endif; ?>
                        <div class="d-flex gap-2">
                            <form class="d-flex gap-2" method="get">
                                <input type="text" class="form-control w-auto" placeholder="Search category"
                                    name="search" value="<?php echo e(request()->search); ?>">
                            </form>
                            <?php if(Auth::user()->authority != 'user'): ?>
                                <a href="<?php echo e(route('categories.create')); ?>"
                                    class="btn btn-dark rounded-pill d-flex justify-content-center align-items-center px-3 py-2 ">
                                    <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24"
                                        viewBox="0 0 24 24" class="me-1">
                                        <path fill="currentColor"
                                            d="M11 13H6q-.425 0-.712-.288T5 12t.288-.712T6 11h5V6q0-.425.288-.712T12 5t.713.288T13 6v5h5q.425 0 .713.288T19 12t-.288.713T18 13h-5v5q0 .425-.288.713T12 19t-.712-.288T11 18z" />
                                    </svg>
                                    <span>Add Category</span>
                                </a>
                            <?php endif; ?>
                        </div>
                    </div>

                    <div class="table-responsive pt-3">
                        <table class="table">
                            <thead>
                                <tr>
                                    <th scope="col">Nama</th>
                                    <?php if(Auth::user()->authority != 'user'): ?>
                                        <th scope="col">Status</th>
                                        <th scope="col"></th>
                                    <?php endif; ?>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__empty_1 = true; $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                    <tr>
                                        <td><?php echo e($category->name); ?></td>
                                        <?php if(Auth::user()->authority != 'user'): ?>
                                            <td>
                                                <?php if($category->active): ?>
                                                    <span class="badge text-bg-primary">Active</span>
                                                <?php else: ?>
                                                    <span class="badge text-bg-danger">Unactive</span>
                                                <?php endif; ?>
                                            </td>
                                            <td class="d-flex justify-content-end gap-2">
                                                <a href="<?php echo e(route('categories.edit', ['category' => $category->id])); ?>"
                                                    class="btn border border-secondary rounded-pill d-flex justify-content-center align-items-center px-4 py-2">Edit
                                                </a>
                                                <form
                                                    action="<?php echo e(route('categories.destroy', ['category' => $category->id])); ?>"
                                                    method="post">
                                                    <?php echo csrf_field(); ?>
                                                    <?php echo method_field('delete'); ?>
                                                    <button
                                                        class="btn btn-danger rounded-pill d-flex justify-content-center align-items-center px-4 py-2">Delete</button>
                                                </form>
                                            </td>
                                        <?php endif; ?>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                    <tr>
                                        <td colspan="3" class="text-center">Belum ada category</td>
                                    </tr>
                                <?php endif; ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>

        </div>

    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal23a33f287873b564aaf305a1526eada4)): ?>
<?php $attributes = $__attributesOriginal23a33f287873b564aaf305a1526eada4; ?>
<?php unset($__attributesOriginal23a33f287873b564aaf305a1526eada4); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal23a33f287873b564aaf305a1526eada4)): ?>
<?php $component = $__componentOriginal23a33f287873b564aaf305a1526eada4; ?>
<?php unset($__componentOriginal23a33f287873b564aaf305a1526eada4); ?>
<?php endif; ?>
<?php /**PATH D:\PIBITI 2024\firstApp\resources\views/category/index.blade.php ENDPATH**/ ?>