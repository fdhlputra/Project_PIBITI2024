<?php if (isset($component)) { $__componentOriginal23a33f287873b564aaf305a1526eada4 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal23a33f287873b564aaf305a1526eada4 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.layout','data' => ['subPage' => 'Orders','title' => 'Create a New Order','subtitle' => 'Fill in the details to create a new order','action' => 'Create Order']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['subPage' => 'Orders','title' => 'Create a New Order','subtitle' => 'Fill in the details to create a new order','action' => 'Create Order']); ?>
    <style>
        .summary-card {
            height: 600px;
            overflow-y: auto;
        }

        .order-stroke {
            border-radius: 15px;
        }

        .order-content {
            height: 100%;
            overflow-x: hidden;
        }

        .order-body {
            display: flex;
            align-items: center;
            justify-content: space-between;
            padding: 10px;
            background-color: white;
            border: 1px solid #ddd;
            margin-bottom: 10px;
        }

        .form-control {
            width: 100%;
            padding: 0.5rem 1rem;
            font-size: 1rem;
            border-radius: 15px;
        }

        .form-control:focus {
            outline: none !important;
            box-shadow: none !important;
        }

        .disabled-link {
            pointer-events: none;
        }
    </style>
    <div class="order-content stroke">
        <div class="d-flex">
            <div class="col">
                <div class="d-grid gap-2">
                    <form class="hstack gap-1" method="get">
                        <select name="category_id" id="category_id" class="form-control w-auto"
                            onchange="this.form.submit()">
                            <option value="">All Categories</option>
                            <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($category->id); ?>"
                                    <?php echo e(request()->category_id == $category->id ? 'selected' : ''); ?>>
                                    <?php echo e($category->name); ?>

                                </option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>

                        <div class="input-group">
                            <input type="text" placeholder="Search product..." class="form-control" name="search"
                                value="<?php echo e(request()->search); ?>" autofocus>
                        </div>
                    </form>

                    <div class="row g-2">
                        <?php $__empty_1 = true; $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                            <div class="col-4">
                                <a href="<?php echo e($product->stock > 0 ? route('orders.create.detail', ['product' => $product->id]) : '#'); ?>"
                                    class="text-decoration-none <?php echo e($product->stock <= 0 ? 'disabled-link' : ''); ?>">
                                    <div class="card product-card">
                                        <?php if($product->stock <= 0): ?>
                                            <div class="sold-overlay">
                                                <div class="sold-text">Out of Stock</div>
                                            </div>
                                        <?php endif; ?>
                                        <img src="<?php echo e(Storage::url($product->image)); ?>" alt="<?php echo e($product->name); ?>"
                                            class="card-img-top mb-2"
                                            style="width: 100%; height: 200px; object-fit: cover;">
                                        <div class="">
                                            <h5 class="card-title"><?php echo e($product->name); ?></h5>
                                            <div class="d-flex flex-column gap-2">
                                                <small class="text-muted"><?php echo e($product->category->name); ?></small>
                                                <small class="text-end fw-medium">
                                                    Rp<?php echo e(number_format($product->price)); ?>

                                                </small>
                                            </div>
                                        </div>
                                    </div>
                                </a>
                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                            <div class="col text-center">
                                <p class="mb-0">Product list is empty</p>
                            </div>
                        <?php endif; ?>
                    </div>




                </div>
            </div>

            
            <div class="col-md-4">
                <form class="order-content order-stroke p-3 bg-light ms-3" method="post"
                    action="<?php echo e(route('orders.checkout')); ?>">
                    <?php echo csrf_field(); ?>
                    <div class="fw-medium fs-4">Summary</div>
                    <hr>
                    <div class="">
                        <?php if (isset($component)) { $__componentOriginal18c21970322f9e5c938bc954620c12bb = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal18c21970322f9e5c938bc954620c12bb = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.text-input','data' => ['name' => 'customer','label' => 'Customer','value' => ''.e(session('order')->customer).'']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('text-input'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['name' => 'customer','label' => 'Customer','value' => ''.e(session('order')->customer).'']); ?> <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal18c21970322f9e5c938bc954620c12bb)): ?>
<?php $attributes = $__attributesOriginal18c21970322f9e5c938bc954620c12bb; ?>
<?php unset($__attributesOriginal18c21970322f9e5c938bc954620c12bb); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal18c21970322f9e5c938bc954620c12bb)): ?>
<?php $component = $__componentOriginal18c21970322f9e5c938bc954620c12bb; ?>
<?php unset($__componentOriginal18c21970322f9e5c938bc954620c12bb); ?>
<?php endif; ?>
                        <hr>
                    </div>
                    <div class="bg-body-tertiary ">
                        <div class="mb-2">List Product</div>
                        <div class="vstack gap-2">
                            <?php
                                $total = 0;
                            ?>
                            <?php $__empty_1 = true; $__currentLoopData = session('order')->details; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $detail): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                <?php
                                    $total += $detail->quantity * $detail->price;
                                ?>
                                <a href="<?php echo e(route('orders.create.detail', ['product' => $detail->product_id])); ?>"
                                    class="text-decoration-none">
                                    <div class="card product-card">
                                        <div class="">
                                            <div><?php echo e($detail->product->name); ?></div>
                                            <div class="d-flex justify-content-between">
                                                <div class="form-text"><?php echo e($detail->quantity); ?> x
                                                    <?php echo e(number_format($detail->price)); ?></div>
                                                <div class="ms-auto form-text">
                                                    Rp<?php echo e(number_format($detail->quantity * $detail->price)); ?></div>
                                            </div>
                                        </div>
                                    </div>
                                </a>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                <div class="text-center text-secondary py-2 border rounded">Product list is empty</div>
                            <?php endif; ?>
                        </div>
                        <hr>
                        <div class="card-body d-grid gap-2">
                            <div class="d-flex justify-content-between">
                                <div>Total</div>
                                <h4 class="ms-auto mb-0 fw-bold">Rp<?php echo e(number_format($total)); ?></h4>
                            </div>
                            <div class="mt-5">
                                <?php if (isset($component)) { $__componentOriginal18c21970322f9e5c938bc954620c12bb = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal18c21970322f9e5c938bc954620c12bb = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.text-input','data' => ['name' => 'payment','label' => 'Payment','type' => 'number','placeholder' => 'Rp.']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('text-input'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['name' => 'payment','label' => 'Payment','type' => 'number','placeholder' => 'Rp.']); ?> <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal18c21970322f9e5c938bc954620c12bb)): ?>
<?php $attributes = $__attributesOriginal18c21970322f9e5c938bc954620c12bb; ?>
<?php unset($__attributesOriginal18c21970322f9e5c938bc954620c12bb); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal18c21970322f9e5c938bc954620c12bb)): ?>
<?php $component = $__componentOriginal18c21970322f9e5c938bc954620c12bb; ?>
<?php unset($__componentOriginal18c21970322f9e5c938bc954620c12bb); ?>
<?php endif; ?>
                            </div>
                        </div>
                        <hr>
                        <div class="d-flex gap-3 w-100 flex-column">
                            <button class="btn btn-dark">Checkout</button>
                            <button name="cancel" class="btn border btn-border-secondary">Cancel</button>
                        </div>
                    </div>
                </form>
            </div>
        </div>
    </div>

 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal23a33f287873b564aaf305a1526eada4)): ?>
<?php $attributes = $__attributesOriginal23a33f287873b564aaf305a1526eada4; ?>
<?php unset($__attributesOriginal23a33f287873b564aaf305a1526eada4); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal23a33f287873b564aaf305a1526eada4)): ?>
<?php $component = $__componentOriginal23a33f287873b564aaf305a1526eada4; ?>
<?php unset($__componentOriginal23a33f287873b564aaf305a1526eada4); ?>
<?php endif; ?>
<?php /**PATH D:\PIBITI 2024\firstApp\resources\views/order/create.blade.php ENDPATH**/ ?>